package com.example.diary_yu;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static String DB_NAME = "mydb";
    private Button btnInsert,btnClear,btnCheck,save;//增设四个按钮事件
    private EditText et_word,et_example,et_meaning;
    public MyDataBaseHelper myDBHelper;//数据库
    public SQLiteDatabase db;//一个数据库的操作类
    private String clickItemWord,ww,wm,we;
    private Cursor cursor;
    private Map<String, Object> item;//listview中每个item的传输工具
    private SimpleAdapter listAdapter;//适配器
    private ListView listview;
    public static ArrayList<Map<String, Object>> data;//在导出listView时，存放当前数据库所有单词信息
    ArrayList wordname = new ArrayList();
    private TextView tv_word,tv_mean,tv_example;
    private PopupWindow popupWindow;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = findViewById(R.id.lv);
        myDBHelper = new MyDataBaseHelper(this, DB_NAME, null, 1);//实例化数据库
        db = myDBHelper.getWritableDatabase();// 打开数据库
        data = new ArrayList<Map<String, Object>>();
        dbFindAll();

        et_word = (EditText)findViewById(R.id.words_name);
        et_meaning = (EditText) findViewById(R.id.words_meaning);
        et_example = (EditText) findViewById(R.id.words_example);


        Configuration mConfiguration = this.getResources().getConfiguration();//获取屏幕方向
        //获取屏幕方向
        int ori = mConfiguration.orientation;
        if (ori == mConfiguration.ORIENTATION_LANDSCAPE) {
            clickLandShow();
            //横屏
        } else if (ori == mConfiguration.ORIENTATION_PORTRAIT) {
            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    item = data.get(i);//item哈希表从ArrayList中得到点击到Item
                    clickItemWord = (String) item.get("word");
                    String word = (String) item.get("word");
                    String wordmeaning = (String) item.get("meaning");
                    String wordexample = (String) item.get("example");

                    EditText wordMeaning = new EditText(MainActivity.this);
                    EditText wordExample = new EditText(MainActivity.this);

                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle(clickItemWord);
                    builder.setMessage("释义:" + wordmeaning + "\n" + "例句:" + wordexample);
                    builder.setNeutralButton("删除", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                                dbDel();
                                dbFindAll();
                        }
                    });
                        //修改释义功能
                    builder.setNegativeButton("修改释义", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
                            builder1.setTitle("修改" + clickItemWord + "的释义");
                            builder1.setMessage("释义：");
                            builder1.setView(wordMeaning);
                            builder1.setPositiveButton("保存", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    String wordMeaning1 = wordMeaning.getText().toString().trim();
                                    ContentValues values = new ContentValues();
                                    values.put("meaning", wordMeaning1);
                                    String[] args = {clickItemWord};
                                    int num = db.update(myDBHelper.TB_NAME, values, "word=?", args);
                                    if (num > 0)
                                        Log.i("myDbDemo", "数据更新成功！");
                                    else
                                        Log.i("myDbDemo", "数据未更新");

                                    dbFindAll();//更新数据
                                }
                            });
                            builder1.create().show();

                        }
                        });
                        //修改例句功能
                        builder.setPositiveButton("修改例句", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
                                builder1.setTitle("修改" + clickItemWord + "的例句");
                                builder1.setMessage("例句：");
                                builder1.setView(wordExample);
                                builder1.setPositiveButton("保存", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        String wordExample1 = wordExample.getText().toString().trim();
                                        ContentValues values = new ContentValues();
                                        values.put("example", wordExample1);
                                        String[] args = {clickItemWord};
                                        int num = db.update(myDBHelper.TB_NAME, values, "word=?", args);
                                        if (num > 0)
                                            Log.i("myDbDemo", "数据更新成功！");
                                        else
                                            Log.i("myDbDemo", "数据未更新");

                                        dbFindAll();//更新数据
                                    }
                                });
                                builder1.create().show();

                            }
                        });
                        builder.create().show();
                }
            });

            //竖屏
        }



        try {
            btnClear = findViewById(R.id.clear);
            btnClear.setOnClickListener(view -> onClickClear());

            btnInsert = findViewById(R.id.insert);
            btnInsert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dbAddNewWord();
                    dbFindAll();
                }
            });

            btnCheck = findViewById(R.id.check);
            btnCheck.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mohu();
                }
            });

        } catch (Exception e) {

        }

    }



    //插入数据
    public void dbAddNewWord() {
        // TODO Auto-generated method stub
        ContentValues values = new ContentValues();
        values.put("word", et_word.getText().toString().trim());//移除字符串空白字符
        values.put("meaning", et_meaning.getText().toString().trim());
        values.put("example", et_example.getText().toString().trim());
        long rowid = db.insert(myDBHelper.TB_NAME, null, values);//向数据库添加value
    }

    //数据删除
    protected void dbDel() {
        // TODO Auto-generated method stub

        db.execSQL("DELETE FROM wordinformation WHERE word = '"+clickItemWord+"' ;");
    }

    //查询当前数据库全部数据数据
    public void dbFindAll() {
        // TODO Auto-generated method stub
        data.clear();
        cursor = db.rawQuery("select * from wordinformation", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            String word = cursor.getString(1);
            String meaning = cursor.getString(2);
            String example = cursor.getString(3);
            item = new HashMap<String, Object>();
            item.put("word", word);
            item.put("meaning", meaning);
            item.put("example", example);
            data.add(item);
            cursor.moveToNext();
        }
        showList();
    }

    public void mohu(){
        data.clear();
        String current_sql_sel = "SELECT  * FROM wordinformation" +" where word like '%"+et_word.getText().toString()+"%'";
        cursor = db.rawQuery(current_sql_sel,null);
        cursor.moveToNext();
        while (!cursor.isAfterLast()) {
            String word = cursor.getString(1);
            String meaning = cursor.getString(2);
            String example = cursor.getString(3);
            item = new HashMap<String, Object>();
            item.put("word", word);
            item.put("meaning", meaning);
            item.put("example", example);
            data.add(item);
            cursor.moveToNext();
        }
        showList();
    }
    private void showList() {
        // TODO Auto-generated method stub
        listAdapter = new SimpleAdapter(this, data,
                R.layout.item, new String[]{"word"},
                new int[]{R.id.txt_words_name});
        listview.setAdapter(listAdapter);
    }

    //利用单词名从数据库中得到那个单词的所有信息
    private ArrayList<Map<String, String>> find(SQLiteDatabase sqLiteDatabase, String word){

        Cursor cursor = sqLiteDatabase.rawQuery("select * from wordinformation where word like ?", new String[]{"%"+word+"%"});
        //利用sql语句进行模糊查询
        ArrayList<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
        while (cursor.moveToNext()){
            Map<String, String> map = new HashMap<String, String>();
            map.put("word",cursor.getString(1));
            map.put("meaning",cursor.getString(2));
            map.put("example",cursor.getString(3));
            resultList.add(map);
        }
        return resultList;
    }

    private void onClickClear(){
        et_word.setText("");
        et_meaning.setText("");
        et_example.setText("");
    }

    public void clickLandShow(){
        ListView lv = findViewById(R.id.lv);
        tv_word = findViewById(R.id.word_tv1);
        tv_mean = findViewById(R.id.mean_tv);
        tv_example = findViewById(R.id.example_tv);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                item = data.get(i);//item哈希表从ArrayList中得到点击到Item
                clickItemWord = (String) item.get("word");
                String word = (String) item.get("word");
                String wordmeaning = (String) item.get("meaning");
                String wordexample = (String) item.get("example");
                tv_word.setText(word);
                tv_mean.setText(wordmeaning);
                tv_example.setText(wordexample);
            }
        });

    }

}
