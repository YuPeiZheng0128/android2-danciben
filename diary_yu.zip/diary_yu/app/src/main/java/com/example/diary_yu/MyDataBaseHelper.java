package com.example.diary_yu;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDataBaseHelper extends SQLiteOpenHelper {
    public static final String TB_NAME = "wordinformation";

    public MyDataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }

    public MyDataBaseHelper(Context context , String baseName , int version)
    {
        super(context , baseName , null , version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //创建表名
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS wordinformation (_id INTEGER PRIMARY KEY AUTOINCREMENT,word VARCHAR(20),meaning VARCHAR(20),example VARCHAR(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + "wordinformation");
        onCreate(sqLiteDatabase);
    }
}
